Proposal
========

Timothy Ong and Sweyn Venderbush
--------------------------------

1. We want to use PySDL2 to have live updating for Python. 
2. After we do this, we will use it to make documentation and an animation demonstrating how it works.
3. If there is still time, we can add mouse interactions that will allow things such as click and drag to rotate.